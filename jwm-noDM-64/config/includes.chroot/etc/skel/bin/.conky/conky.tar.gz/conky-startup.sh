#!/bin/bash

# sh /home/simon/.conky-startup.sh

(conky --pause=3 -c ~/conky/.conkyrc.main) &
(conky --pause=3 -c ~/conky/.conkyrc.keys) & 
(conky --pause=3 -c ~/conky/.conkyrc.clock) & 

